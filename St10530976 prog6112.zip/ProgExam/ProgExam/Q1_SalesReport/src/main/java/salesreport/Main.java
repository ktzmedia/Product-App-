package salesreport;

import java.util.Scanner;

/**
 * Q1 - Console application that captures three months of sales for
 * three mattresses and prints the product sales report.
 */
public class Main {

    // One Scanner shared by the whole class
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {

        // Single dimensional array of product names
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        int months = 3;

        // Two dimensional array: rows = products, columns = months
        int[][] sales = new int[productNames.length][months];

        // Capture the sales for each product, month by month
        for (int p = 0; p < productNames.length; p++) {
            for (int m = 0; m < months; m++) {
                sales[p][m] = readSales("Enter number of sales for month "
                        + (m + 1) + " for " + productNames[p] + ": ");
            }
            System.out.println(); // blank line between products
        }

        // The report uses short product names (without the word mattress)
        String[] reportNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        // Create the Product object and the printing object
        Product product = new Product(reportNames, sales);
        PrintProduct printer = new PrintProduct(product);

        // Print the report
        System.out.println();
        printer.printHeading();
        printer.printTotalProductSales();
        printer.printAverageProductSales();
        printer.printMostPopularProduct();
    }

    // Keeps asking until the user enters a whole number that is not negative
    private static int readSales(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = input.nextLine().trim();
            try {
                int value = Integer.parseInt(text);
                if (value >= 0) {
                    return value;
                }
                System.out.println("Sales cannot be negative. Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }
}
