package salesreport;

/**
 * Interface that every product report class must implement.
 * It lists the three calculations the sales report needs.
 */
public interface IProduct {

    // Adds up every sale for every product and every month
    int GetTotalProductsSold();

    // Average number of products sold per product per month
    double GetAverageProductSold();

    // Name (and total sales) of the product with the highest total sales
    String GetMostPopularProduct();
}
