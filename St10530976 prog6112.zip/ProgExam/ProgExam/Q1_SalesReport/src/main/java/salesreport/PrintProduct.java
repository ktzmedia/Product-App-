package salesreport;

import java.text.DecimalFormat;

/**
 * Responsible only for printing the report data.
 * The calculations are done by the Product class.
 */
public class PrintProduct {

    // Product object that supplies the calculated values
    private final IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    // Prints the report heading and the line of asterisks
    public void printHeading() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("*****************************************");
    }

    // Prints the total number of products sold
    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    // Prints the average; 0.## shows 17 instead of 17.0 but keeps decimals if needed
    public void printAverageProductSales() {
        DecimalFormat df = new DecimalFormat("0.##");
        System.out.println("AVERAGE PRODUCT SALES: " + df.format(product.GetAverageProductSold()));
    }

    // Prints the most popular product
    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
