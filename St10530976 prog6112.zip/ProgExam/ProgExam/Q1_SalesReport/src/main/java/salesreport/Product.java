package salesreport;

/**
 * Holds the sales data and does the report calculations.
 * Uses a single dimensional array for the product names and
 * a two dimensional array for the sales figures.
 */
public class Product implements IProduct {

    // Single dimensional array: one name per product
    private final String[] productNames;

    // Two dimensional array: sales[product][month]
    private final int[][] sales;

    // Constructor receives the names and the sales figures
    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    // Adds up every value in the two dimensional array
    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        // Outer loop moves through the products (rows)
        for (int p = 0; p < sales.length; p++) {
            // Inner loop moves through the months (columns)
            for (int m = 0; m < sales[p].length; m++) {
                total += sales[p][m];
            }
        }
        return total;
    }

    // Total divided by the number of sales entries (products x months)
    @Override
    public double GetAverageProductSold() {
        int entries = 0;
        for (int p = 0; p < sales.length; p++) {
            entries += sales[p].length;
        }

        // Avoid dividing by zero if there is no data
        if (entries == 0) {
            return 0;
        }
        return (double) GetTotalProductsSold() / entries;
    }

    // Finds the product whose row of sales adds up to the highest amount
    @Override
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        int bestTotal = -1;

        for (int p = 0; p < sales.length; p++) {
            // Total sales for this one product across all months
            int productTotal = 0;
            for (int m = 0; m < sales[p].length; m++) {
                productTotal += sales[p][m];
            }

            // Keep the product with the highest total so far
            if (productTotal > bestTotal) {
                bestTotal = productTotal;
                bestIndex = p;
            }
        }
        return productNames[bestIndex] + "(" + bestTotal + ")";
    }
}
