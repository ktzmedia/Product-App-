package test;

import productapp.ProductCalculations;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Q2.6 - Unit tests for the ProductCalculations class.
 * Uses the R3500 price from the sample screenshot.
 */
public class ProductCalculationsTest {

    // Unit Test 1: 15% of 3500 is 525
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations();
        assertEquals(525.0, calc.GetVat(3500), 0.001);
    }

    // Unit Test 2: 3500 + 525 + 175 is 4200
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations();
        assertEquals(4200.0, calc.GetTotal(3500), 0.001);
    }
}
