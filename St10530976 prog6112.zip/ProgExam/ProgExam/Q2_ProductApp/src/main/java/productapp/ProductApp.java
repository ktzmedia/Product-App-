package productapp;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Q2 - Product App (Swing GUI) for the mattress company.
 * Captures the customer and product, calculates VAT, commission and
 * the total, shows them in a message box and saves them to data.txt.
 */
public class ProductApp extends JFrame {

    // File the sale details are saved to
    private static final String FILE_NAME = "data.txt";

    // Mattress products shown in the combo box
    private static final String[] PRODUCTS = {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    };

    // Form components
    private final JTextField txtCustomer = new JTextField(18);
    private final JComboBox<String> cmbProduct = new JComboBox<>(PRODUCTS);
    private final JTextField txtPrice = new JTextField(18);
    private final JButton btnProcess = new JButton("PROCESS");

    // Object that does the calculations
    private final ProductCalculations calc = new ProductCalculations();

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        buildMenu();
        buildForm();

        pack();
        setLocationRelativeTo(null); // centre on screen
    }

    // Q2.4 - Menu system: File > Exit, Tools > Process, Clear
    private void buildMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        // Exit closes the application
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        // Process menu item uses the same logic as the Process button
        processItem.addActionListener(e -> processSale());
        // Clear menu item empties the text boxes and resets the combo box
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    // Q2.1 / Q2.2 - Lays out the labels, text boxes, combo box and button
    private void buildForm() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 15, 10, 15);
        c.anchor = GridBagConstraints.WEST;

        // Row 0: customer name
        c.gridx = 0; c.gridy = 0;
        add(new JLabel("Customer Name:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        add(txtCustomer, c);

        // Row 1: product combo box
        c.gridx = 0; c.gridy = 1; c.fill = GridBagConstraints.NONE;
        add(new JLabel("Select Product:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        add(cmbProduct, c);

        // Row 2: price
        c.gridx = 0; c.gridy = 2; c.fill = GridBagConstraints.NONE;
        add(new JLabel("Enter Price:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        add(txtPrice, c);

        // Row 3: process button
        c.gridx = 1; c.gridy = 3;
        add(btnProcess, c);

        // Q2.3 - Button click runs the same method the menu item uses
        btnProcess.addActionListener(e -> processSale());
    }

    // Q2.3 - Validates the input, calculates, displays and saves the sale
    private void processSale() {
        String customer = txtCustomer.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        // Customer name must be entered
        if (customer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer name.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Price must be a positive number
        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
            if (price <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price greater than 0.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calculations
        double vat = calc.GetVat(price);
        double commission = calc.GetCommission(price);
        double total = calc.GetTotal(price);

        // Show the result in a message box
        String message = "Customer Name: " + customer
                + "\nProduct: " + product
                + "\nVAT: R " + vat
                + "\nCOMMISSION: R " + commission
                + "\nTOTAL: R " + total;
        JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);

        // Save the same details to data.txt
        saveToFile(customer, product, vat, commission, total);
    }

    // Appends the sale to data.txt so earlier sales are not overwritten
    private void saveToFile(String customer, String product,
                            double vat, double commission, double total) {
        // try-with-resources closes the file automatically
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println("DATA LOG");
            out.println("*****************************");
            out.println("Customer Name: " + customer);
            out.println("Product: " + product);
            out.println("VAT: R " + vat);
            out.println("COMMISSION: R " + commission);
            out.println("TOTAL: R " + total);
            out.println("*****************************");
            out.println();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save to " + FILE_NAME + ": " + ex.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Q2.4 - Clears the text boxes and sets the combo box index back to 0
    private void clearForm() {
        txtCustomer.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
        txtCustomer.requestFocus();
    }

    public static void main(String[] args) {
        // Swing screens should be created on the event dispatch thread
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
