package productapp;

/**
 * Q2.5 - Holds the sale calculations so they can be unit tested
 * without needing the GUI.
 */
public class ProductCalculations {

    // VAT is 15% of the product price
    public double GetVat(double price) {
        return price * 0.15;
    }

    // Commission is 5% of the product price
    public double GetCommission(double price) {
        return price * 0.05;
    }

    // Total sale amount = price + VAT + commission
    public double GetTotal(double price) {
        return price + GetVat(price) + GetCommission(price);
    }
}
